const mongoose = require('mongoose');
const Schema = mongoose.Schema;
mongoose.connect('mongodb://localhost:27017//dbname', { useNewUrlParser: true })

const SectasSchema = Schema({
    email: String,
    password: String,
    raza: String,
    token: String
})

module.exports = mongoose.model('Miembro', SectasSchema)