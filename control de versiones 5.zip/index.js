const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const nodeMailer = require('nodemailer');
const validator = require("email-validator");
const MongoClient = require('mongodb').MongoClient;
const databaseUrl = "mongodb://localhost:27017/";

const server = express();
const listenPort = 8080;
const domain = `http://localhost:${listenPort}`

server.use(express.static('public'))

server.use(bodyParser.urlencoded({ extended: false }));
server.use(bodyParser.json());

function makeid(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}


function sendMailWithToken(adress, token) {
    let transporter = nodeMailer.createTransport({
        service: 'hotmail',
        auth: {
            // should be replaced with real sender's account
            user: 'silvia.2@hotmail.com.ar',
            pass: 'heladodetrufa-12'
        }
    });
    let mailOptions = {
        // should be replaced with real recipient's account
        to: adress,
        subject: "You successfully enter in our page",
        text: `Para verificar tu cuenta entra en ${token}`
    };
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log(error);
        }
        console.log('Message %s sent: %s', info.messageId, info.response);
    });
}

function sendMailVerified(adress, token) {
    let transporter = nodeMailer.createTransport({
        service: 'hotmail',
        auth: {
            // should be replaced with real sender's account
            user: 'silvia.2@hotmail.com.ar',
            pass: ''
        }
    });
    let mailOptions = {
        // should be replaced with real recipient's account
        to: adress,
        subject: "Registro Confirmado",
        text: `Entra aquí para registrarte ` //falta poner en enlace a login
    };
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            return console.log(error);
        }
        console.log('Message %s sent: %s', info.messageId, info.response);
    });
}

server.post('/signup', (req, res) => {

    let password = req.body.password;
    let email = req.body.email

    if ((password.length < 10 || password.length > 20) || (email.length < 10 || email.length > 40) || !validator.validate(email)) {
        res.redirect('/');

    } else {
        res.redirect('/ConfirmEmail');
        let token = makeid(10)
        sendMailWithToken(email, `${domain}/ConfirmEmail/checkEmail?token=${token}`)

        MongoClient.connect(databaseUrl, (err, database) => {
            let exercice = database.db('exercice');
            let sectaobject = {
                email: req.body.email,
                password: req.body.password,
                raza: req.body.raza,
                token: token
            }
            exercice.collection('sectamembers').insertOne(sectaobject);
            database.close()
        });
    }
})

server.get('/ConfirmEmail', (req, res) => {
    res.sendFile(path.join(__dirname, '/public', 'confirm.html'));
})
server.get('ConfirmEmail/checkEmail?token=:token', (req, res) => {
    //res.send({ message: `Hola ${req.params.token}` })
    MongoClient.connect(databaseUrl, (err, database) => {
        let exercice = database.db('exercice');
        let comparetoken = req.params.token

        function gettoken(sectaobject) {
            return sectaobject.token;
        }

        let showtokens = exercice.collection('sectamembers').find({ "token": 1, "_id": 0 }).map(gettoken)

        if (showtokens.find(element => element === comparetoken)) {
            sendMailVerified()
        } else {
            alert('No puedes acceder a los datos')
            res.redirect('/');
        }

        database.close()
    });
})



server.listen(listenPort, () => console.log(`Server started listening on ${listenPort}`));